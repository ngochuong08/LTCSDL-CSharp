﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NorthwindApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        #region 1Lop
        SqlConnection sqlConn; //khai báo biến connection

        string cnStr;
        //1 Tạo kết nối
        void KetnoiCSDL() //thực hiện kết nối bằng chuỗi kết nối
        {

            cnStr = ConfigurationManager.ConnectionStrings["cnstr"].ConnectionString;
            sqlConn = new SqlConnection(cnStr);


        }
        //2 Đọc dữ liệu

        DataTable layDanhSachNhanVien() //lấy danh sách nhân viên
        {
            string sql = "Select * from Employees";
            SqlDataAdapter da = new SqlDataAdapter(sql, sqlConn);
            DataSet ds = new DataSet();
            da.Fill(ds);//ds chứa ds NV
            return ds.Tables[0];//bảng Nv 1 datatable
        }
        //Load data từ datatable lên LV
        void LoadListview()
        {

            lsvNhanVien.FullRowSelect = true; //cho phép chọn 1 dòng
            lsvNhanVien.View = View.Details; //cho phép hiển thị thông tin chi tiết dạng bảng
            DataTable dt = layDanhSachNhanVien();//

            lsvNhanVien.View = View.Details;
            //so cot cua LV
            lsvNhanVien.Columns.Add("MaNV", 0);
            lsvNhanVien.Columns.Add("Họ và tên", 200);
            lsvNhanVien.Columns.Add("Ngày sinh:", 100);
            lsvNhanVien.Columns.Add("Địa chỉ", 200);
            lsvNhanVien.Columns.Add("Điện thoại", 100);



            for (int i = 0; i < dt.Rows.Count; i++)
            {

                ListViewItem lvi = new ListViewItem(dt.Rows[i]["EmployeeID"].ToString());

                //dòng thứ i, tên cột là nhân viên
                lvi.SubItems.Add(dt.Rows[i][2].ToString()); //Lay cac thuoc tinh: NS
                lvi.SubItems.Add(dt.Rows[i][5].ToString()); //Lay cac thuoc tinh: NS

                lvi.SubItems.Add(dt.Rows[i][7].ToString()); //DC

                lvi.SubItems.Add(dt.Rows[i][12].ToString()); //DT

                lsvNhanVien.Items.Add(lvi);

            }


        }

        public void XoaNhanVien(string index_nv)
        {
            string sql = "Delete from Employees where EmployeeID = " + index_nv;
            SqlCommand cmd = new SqlCommand(sql, sqlConn);
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            lsvNhanVien.Items.Clear();
            LoadListview();

        }

        #endregion//không xài

        //3Lop

        #region 3lop
        //GUI: đổ data tư datatable lên LV
        /*1. Có sc từ datatable//BUS
         * 2. định nghĩa LV: bao nhiu cột.GUI
         * 3. đổ datatable vào lv: GUI
         */

      
        NhanVien nv = new NhanVien();//khởi tạo chuỗi kết nối đến database
        void HienThiNV()
        {
            
           

            NumericUpDownColumn c = new NumericUpDownColumn();
            c.HeaderText = "Cot1";
            c.Name = "Cot1";
            dataGridView1.Columns.Add(c);
            dataGridView1.Rows[0].Cells[0].Value = 0;
            DataGridViewTextBoxColumn TextBoxCell = new DataGridViewTextBoxColumn();
            TextBoxCell.Name = "cot2";
            TextBoxCell.HeaderText = "Cot2";
            dataGridView1.Columns.Add(TextBoxCell);
            DataGridViewCheckBoxColumn chk = new DataGridViewCheckBoxColumn();
            chk.Name = "cot3";
            chk.HeaderText = "Cot3";
            dataGridView1.Columns.Add(chk);


            lsvNhanVien.Items.Clear();
            foreach (Employee e in nv.LayDSNhanVien())
            {
                //lấy từng dòng đổ vào LV
                ListViewItem lvi = new ListViewItem(e.EmployeeID.ToString());

                //dòng thứ i, tên cột là nhân viên
                lvi.SubItems.Add(e.LastName.ToString()); //Lay cac thuoc tinh: NS
                lvi.SubItems.Add(e.BirthDate.ToString()); ; //Lay cac thuoc tinh: NS

                lvi.SubItems.Add(e.Address.ToString()); //DC

                lvi.SubItems.Add(e.HomePhone.ToString()); ; //DT

                lsvNhanVien.Items.Add(lvi);
            }




        }
        public void HienThiNhom()
        {

            cbNhom.DataSource = nv.LayDSNhom();
            cbNhom.DisplayMember = "GroupName";//DTO-> class Groups
            cbNhom.ValueMember = "GroupID";// là tên thuộc tính trong database
            cbNhom.SelectedIndex = 1;

        }
        //3 lơp: độc lập giữa GUI và DAO

        private void Form1_Load(object sender, EventArgs e)
        {

            //KetnoiCSDL();

            //LoadListview();

            //3Lop
            //2. Định nghĩa LV
           
            lsvNhanVien.FullRowSelect = true; //cho phép chọn 1 dòng
            lsvNhanVien.View = View.Details; //cho phép hiển thị thông tin chi tiết dạng bảng
            lsvNhanVien.View = View.Details;
            //so cot cua LV
            lsvNhanVien.Columns.Add("MaNV", 0);
            lsvNhanVien.Columns.Add("Họ và tên", 200);
            lsvNhanVien.Columns.Add("Ngày sinh:", 100);
            lsvNhanVien.Columns.Add("Địa chỉ", 200);
            lsvNhanVien.Columns.Add("Điện thoại", 100);
            //3
            HienThiNV();

            HienThiNhom();


        }

        private void lsvNhanVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvNhanVien.SelectedItems.Count > 0)
            {
                txtHoten.Text = lsvNhanVien.SelectedItems[0].SubItems[1].Text;
                dtpNgaySinh.Text = lsvNhanVien.SelectedItems[0].SubItems[2].Text;
                txtDiaChi.Text = lsvNhanVien.SelectedItems[0].SubItems[3].Text;
                txtDienThoai.Text = lsvNhanVien.SelectedItems[0].SubItems[4].Text;
            }
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            #region 1lop
            //string sql = string.Format("Insert into Employees ([LastName],[FirstName],[BirthDate] ,[Address] ,[HomePhone] ) values(N'{0}','{1}',N'{2}','{3}','{4}')", txtHoten.Text, txtHoten.Text, dtpNgaySinh.Value.ToShortDateString(), txtDiaChi.Text, txtDienThoai.Text);

            //SqlCommand cmd = new SqlCommand(sql, sqlConn);
            //cmd.Connection.Open();
            //cmd.ExecuteNonQuery();
            //cmd.Connection.Close();
            //lsvNhanVien.Items.Clear();
            //LoadListview(); 
            #endregion

            #region 3lop
            //nv.ThemNV(txtHoten.Text, txtHoten.Text, dtpNgaySinh.Value.ToShortDateString(), txtDiaChi.Text, txtDienThoai.Text, cbNhom.SelectedIndex);
            //lsvNhanVien.Items.Clear();
            //HienThiNV(); 
            #endregion

            nv.ThemNV(txtHoten.Text, txtHoten.Text,
                dtpNgaySinh.Value.ToShortDateString(),
                txtDiaChi.Text, txtDienThoai.Text, cbNhom.SelectedIndex);
            HienThiNV();
            //1. lấy data từ các tb, cb: GUI
            //lưu vào database: truyến query BUS, kết nối DA, thực thi: DAO
        }

        void setNull()
        {
            txtHoten.Text = "";
            txtDiaChi.Text = "";
            txtDienThoai.Text = "";
        }
        private void btXoa_Click(object sender, EventArgs e)
        {
            if (lsvNhanVien.SelectedIndices.Count > 0)
            {
                DialogResult dr = MessageBox.Show("Bạn có chắc xóa  không?", "Xóa bằng cấp", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    ////XoaNhanVien(lsvNhanVien.SelectedItems[0].SubItems[0].Text); 
                    //nv.XoaNhanVien(lsvNhanVien.SelectedItems[0].SubItems[0].Text);
                    //lsvNhanVien.Items.RemoveAt(lsvNhanVien.SelectedIndices[0]);
                    //setNull();

                    nv.XoaNhanVien(lsvNhanVien.SelectedItems[0].SubItems[0].Text);
                    HienThiNV();
                }
            }
            else
                MessageBox.Show("Bạn phải chọn mẩu tin cần xóa");


        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            //VD Lấy tổng NV
            string sql = "SELECT COUNT(employeeID) FROM Employees";


            SqlCommand cmd = new SqlCommand(sql, sqlConn);
            cmd.Connection.Open();
            int count = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();
            MessageBox.Show(count.ToString());

        }

        private void btSua_Click(object sender, EventArgs e)
        {
            if (lsvNhanVien.SelectedIndices.Count > 0)
            {
                #region 3lop
                ////MessageBox.Show(lsvNhanVien.SelectedItems[0].SubItems[0].Text + txtHoten.Text + txtHoten.Text + dtpNgaySinh.Value.ToShortDateString() + txtDiaChi.Text + txtDienThoai.Text + cbNhom.SelectedValue.ToString());
                //nv.CapNhatNV(Int16.Parse(lsvNhanVien.SelectedItems[0].SubItems[0].Text), txtHoten.Text, txtHoten.Text, dtpNgaySinh.Value.ToShortDateString(), txtDiaChi.Text, txtDienThoai.Text, cbNhom.SelectedIndex);
                //lsvNhanVien.Items.Clear();
                //HienThiNV(); 
                #endregion

                nv.CapNhatNV(Int16.Parse(lsvNhanVien.SelectedItems[0].SubItems[0].Text), txtHoten.Text, txtHoten.Text, dtpNgaySinh.Value.ToShortDateString(), txtDiaChi.Text, txtDienThoai.Text, cbNhom.SelectedIndex);
                HienThiNV();
            }
            else
                MessageBox.Show("Cần chọn mẫu tin muốn sửa", "Sửa nhân viên");
        } 


        #endregion
    }
}
