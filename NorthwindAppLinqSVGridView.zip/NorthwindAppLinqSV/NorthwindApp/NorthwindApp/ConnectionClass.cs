﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;//SQL
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NorthwindApp
{
    /*DAO: KetnoiCSDL: truyền chuỗi kết nối, gọi thực thi
        * BUS: gọi phương thức: thêm sửa xóa, lấy Data, truyền các câu query liên quan, 
        * trả về data liên quan
        * GUI: đổ data tư datatable lên 
        */
    class ConnectionClass//DAO
    {
        //Update, Delete, Insert
        SqlConnection sqlConn;//Đối tượng kết nối CSDL//using System.Data.SqlClient;
        SqlDataAdapter da; //Đối tượng điều phối DL
        DataSet ds;//Đói tượng chứa CSDL

        public ConnectionClass()//
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cnstr"].ConnectionString;//using System.Configuration;
            sqlConn = new SqlConnection(cnStr);
        }
        //Phương thức thực thi câu lệnh SQL truy vấn dữ liệu//đọc
        public DataTable Execute(string sqlStr) //using System.Data;
        {
            da = new SqlDataAdapter(sqlStr, sqlConn);
            ds = new DataSet();
            da.Fill(ds);
            return ds.Tables[0];
        }
    
        //Phương thức thực thi câu lệnh Thêm, Xóa, Sửa
        public void ExecuteNonQuery(string sqlStr) //ghi
        {
            try
            {
                SqlCommand sqlCmd = new SqlCommand(sqlStr, sqlConn);
                sqlConn.Open();//Mở kết nối
                sqlCmd.ExecuteNonQuery();//Lệnh thêm/sửa/xóa
            }
            catch (SqlException e)
            {

                ;
            }
            finally
            {
                sqlConn.Close();//Đóng kết nối 
            }
        }
    }
}
//3 lớp
//Quản lý NV
/*
 * Form QLNV
 * DAO: mở đóng kết nối, thực thi 
 * BUS: thêm, sửa, xóa, hiển thị
 */
