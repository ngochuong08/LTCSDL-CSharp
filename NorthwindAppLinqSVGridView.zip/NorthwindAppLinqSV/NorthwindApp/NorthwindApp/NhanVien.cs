﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NorthwindApp
{
    class NhanVien//BUS
    {
        
        //Truyền chuỗi kết nối
        SqlConnection sqlConn;
        string cnStr = ConfigurationManager.ConnectionStrings["cnstr"].ConnectionString;
        //Đối tượng chứa database (Linq)
        NWDataContext nwD;

        public NhanVien()
        {
            sqlConn = new SqlConnection(cnStr);//Conn
            nwD = new NWDataContext(sqlConn);//Lay Data
        }
        public IEnumerable<Employee> LayDSNhanVien()//using System.Data;
        {

            IEnumerable<Employee> emp = nwD.GetTable<Employee>();
           
            return emp;
        }
        public List<Employee> LoadRecord(int page, int recordNumber)
        {
            //page = 3;
            //recordNumber = 10;
            
            List<Employee> emp = nwD.Employees
                                    .Skip((page - 1) * recordNumber)
                                    .Take(recordNumber).ToList();
           
           
            return emp;
        }

        public int DemNV()
        {
            return nwD.sp_DemNhanVien();
        }
       
        //Lấy tên các nhóm NV
        public IEnumerable<Group> LayDSNhom()
        {

            return nwD.GetTable<Group>();
        }

        public void XoaNhanVien(string index_nv)
        {
            //string sql = "Delete from Employees where EmployeeID = " + index_nv;
            ////connClass.ExecuteNonQuery(sql);
            ///
            Employee e = nwD.Employees.FirstOrDefault(s=>s.EmployeeID.Equals(index_nv));
            nwD.Employees.DeleteOnSubmit(e);
            nwD.SubmitChanges();

        }
        public void ThemNV(string ln, string fn, string bd, string add, string hp, int g)
        {
            //string str = string.Format("Insert into Employees ([LastName],[FirstName],[BirthDate] ,[Address] ,[HomePhone],[GroupID] ) values(N'{0}','{1}',N'{2}','{3}','{4}',{5})", ln, fn, bd, add, hp, g);

            // connClass.ExecuteNonQuery(str);//
            Employee e = new Employee();
            e.LastName = ln;
            e.FirstName = fn;
            e.BirthDate = DateTime.Parse(bd);
            e.Address = add;
            e.HomePhone = hp;
            e.GroupID = g;
            nwD.Employees.InsertOnSubmit(e);
            nwD.SubmitChanges();
        }
        public void CapNhatNV(int indexNV, string ln, string fn, string bd, string add, string hp, int g)
        {
            //string str = string.Format("update Employees set[LastName] = N'{0}', [FirstName] = N'{1}'," +
            //    "[BirthDate] = '{2}', [Address] = '{3}',[HomePhone] = '{4}', [GroupID] = '{5}' " +
            //    "where[EmployeeID] ={6}", ln, fn, bd, add, hp, g, indexNV);
            ////connClass.ExecuteNonQuery(str);
            ///

            Employee e = nwD.Employees.FirstOrDefault(s=>s.EmployeeID.Equals(indexNV));
            e.LastName = ln;
            e.FirstName = fn;
            e.BirthDate = DateTime.Parse( bd);
            e.Address = add;
            e.HomePhone = hp;
            e.GroupID = g;
            nwD.SubmitChanges();

        }
    }
}

/* 50% Hạn nộp: 12/6
 * -> Login
 * 3 lớp: Data Set, Linq
1. Quản lý nhân viên:  

2. Quản lý đọc giả: Thêm - sửa - xóa - hiển thị

3. Quản lý sách: Thêm - Xóa - Sửa 
    - Tìm kiếm sách: Tiêu đề, Tác giả, (Nội dung +)

4. Quản lý mượn trả: 
    Quản lý mượn
    Quản lý trả
    (--Thống kê sách chưa trả +)
    CTPhieuMuon (MaPhieuMuon, MaSach, NgayTra)
 
*/
