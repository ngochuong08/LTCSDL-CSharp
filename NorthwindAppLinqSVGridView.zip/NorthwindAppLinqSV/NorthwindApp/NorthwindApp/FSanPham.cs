﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NorthwindApp
{//mô hình 1 lớp
    public partial class FSanPham : Form
    {
        public FSanPham()
        {
            InitializeComponent();
        }
        //Truyền chuỗi kết nối
        SqlConnection sqlConn;
        string cnStr = ConfigurationManager.ConnectionStrings["cnstr"].ConnectionString;
        //Đối tượng chứa database (Linq)
        NWDataContext nwD;

        private void FSanPham_Load(object sender, EventArgs e)
        {
            sqlConn = new SqlConnection(cnStr);//Conn
            nwD = new NWDataContext(sqlConn);//Lay Data
            LoadDL();
        }
        void LoadDL()
        {
            var sp = nwD.GetTable<Product>().Select(s => new
            {
                s.ProductID,
                s.ProductName,
                s.CategoryID,
                s.SupplierID,
                s.QuantityPerUnit,
                s.UnitPrice
            });
            gVSanPham.DataSource = sp;
        }
        private void btThem_Click(object sender, EventArgs e)
        {
            Product p = new Product();//Tạo mới SP
            p.ProductID = 202;
            p.ProductName = "Gạo";
            nwD.Products.InsertOnSubmit(p);
            nwD.SubmitChanges();
            //thêm dòng vào dg
            //load lại data vào dg
            LoadDL();
        }

        private void btSua_Click(object sender, EventArgs e)
        {
            //Sửa sản phẩm mã 201, sửa tên SP
            //lấy p có mã 201. sửa tên sp
            Product p = nwD.Products.FirstOrDefault(s => s.ProductID.Equals(201));//
            p.ProductName = "Chè";
           // p.UnitPrice = Int32.Parse(txtDonGia.Text);
            nwD.SubmitChanges();
            LoadDL();
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            //Xóa SP 202
            Product p = nwD.Products.FirstOrDefault(s=>s.ProductID.Equals(202)); //Lấy ra 1 SP có mã là 202
            nwD.Products.DeleteOnSubmit(p);//dòng p: p là 1 SP
            nwD.SubmitChanges();
            LoadDL();
        }
    }
}
