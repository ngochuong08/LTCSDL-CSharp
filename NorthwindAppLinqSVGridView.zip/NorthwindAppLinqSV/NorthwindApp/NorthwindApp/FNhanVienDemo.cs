﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NorthwindApp
{
    public partial class FNhanVienDemo : Form
    {
        public FNhanVienDemo()
        {
            InitializeComponent();
        }
        #region 3lop
        //GUI: đổ data tư datatable lên LV
        /*1. Có sc từ datatable//BUS
         * 2. định nghĩa LV: bao nhiu cột.GUI
         * 3. đổ datatable vào lv: GUI
         */


        NhanVien nv = new NhanVien();//khởi tạo chuỗi kết nối đến database
        int nPage = 1;
        int nRecord = 5;
        void HienThiNV()
        {
            LoadButtons(dataGridView1);
            dataGridView1.DataSource = nv.LayDSNhanVien();
            dataGridView1.DataSource = nv.LoadRecord(nPage, nRecord);
           // dataGridView1.Rows[0].Cells["NumericUpDown"].Value = 0;

            dataGridView1.Columns["EmployeeID"].Visible = false;//option

            //Phân trang
            // dataGridView1.DataSource = nv.LoadRecord(nPage, nRecord);

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiNV();

        }



        void LoadButtons(DataGridView gd)
        {

            DataGridViewTextBoxColumn TextBoxCell = new DataGridViewTextBoxColumn();
            TextBoxCell.Name = "TextBox";
            TextBoxCell.HeaderText = "TextBox";
            gd.Columns.Add(TextBoxCell);

            DataGridViewCheckBoxColumn chk = new DataGridViewCheckBoxColumn();
            chk.Name = "CheckBox";
            chk.HeaderText = "CheckBox";
            gd.Columns.Add(chk);

            //Edit link

            DataGridViewLinkColumn Editlink = new DataGridViewLinkColumn();
            Editlink.UseColumnTextForLinkValue = true;
            Editlink.HeaderText = "Edit";
            Editlink.DataPropertyName = "lnkColumn";
            Editlink.LinkBehavior = LinkBehavior.SystemDefault;
            Editlink.Text = "Edit";
            gd.Columns.Add(Editlink);

            //Delete Button


            DataGridViewButtonColumn DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.HeaderText = "Delete";//
            DeleteButton.Text = "Delete";
            DeleteButton.Name = "btDelete";//
            DeleteButton.UseColumnTextForButtonValue = true;
            gd.Columns.Add(DeleteButton);


            #region NumericUpDownColumn
            NumericUpDownColumn c = new NumericUpDownColumn();
            c.HeaderText = "NumericUpDown";
            c.Name = "NumericUpDown";
            gd.Columns.Add(c);
           


            #endregion
        }

        private void btThem_Click(object sender, EventArgs e)
        {

        }

        void setNull()
        {
            txtHoten.Text = "";
            txtDiaChi.Text = "";
            txtDienThoai.Text = "";
        }
        private void btXoa_Click(object sender, EventArgs e)
        {
            //if (lsvNhanVien.SelectedIndices.Count > 0)
            //{
            //    DialogResult dr = MessageBox.Show("Bạn có chắc xóa  không?", "Xóa bằng cấp", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //    if (dr == DialogResult.Yes)
            //    {
            //        HienThiNV();
            //    }
            //}
            //else
            //    MessageBox.Show("Bạn phải chọn mẩu tin cần xóa");


        }

        private void btThoat_Click(object sender, EventArgs e)
        {


        }

        private void btSua_Click(object sender, EventArgs e)
        {
            //if (lsvNhanVien.SelectedIndices.Count > 0)
            //{
            //    HienThiNV();
            //}
            //else
            //    MessageBox.Show("Cần chọn mẫu tin muốn sửa", "Sửa nhân viên");
        }


        #endregion

      
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.RowIndex >= 0)
            //{

            //    DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            //    if (row != null)
            //{ 
            //    txtHoten.Text = row.Cells["LastName"].Value.ToString();
            //    dtpNgaySinh.Text = row.Cells["BirthDate"].Value.ToString();
            //    txtDiaChi.Text = row.Cells["Address"].Value.ToString();
            //    txtDienThoai.Text = row.Cells["HomePhone"].Value.ToString();

            //}
            //if (e.RowIndex >= 0)
            //{
            //    var selectedEmployee = dataGridView1.Rows[e.RowIndex].DataBoundItem as Employee;
            //    txtHoten.Text = selectedEmployee.LastName.ToString();
            //    dtpNgaySinh.Text = selectedEmployee.BirthDate.ToString();
            //    txtDiaChi.Text = selectedEmployee.Address.ToString();
            //    txtDienThoai.Text = selectedEmployee.HomePhone.ToString();
            //}

            if (dataGridView1.Columns[e.ColumnIndex].Name == "btDelete")
            {
                MessageBox.Show("123");
                dataGridView1.Refresh();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.RowIndex >= 0)
            //{
            //    dataGridView1.CurrentCell.Selected = true;
            //    txtHoten.Text = dataGridView1.Rows[e.RowIndex].Cells["LastName"].Value.ToString();
            //    dtpNgaySinh.Value = DateTime.Parse(dataGridView1.Rows[e.RowIndex].Cells["BirthDate"].Value.ToString());
            //    txtDiaChi.Text = dataGridView1.Rows[e.RowIndex].Cells["Address"].Value.ToString();
            //    txtDienThoai.Text = dataGridView1.Rows[e.RowIndex].Cells["HomePhone"].Value.ToString();
            //}

            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count - 1)//xử lý lỗi
            {
                var selectedEmployee = dataGridView1.Rows[e.RowIndex].DataBoundItem as Employee;
                txtHoten.Text = selectedEmployee.LastName.ToString();
                dtpNgaySinh.Text = selectedEmployee.BirthDate.ToString();
                txtDiaChi.Text = selectedEmployee.Address.ToString();
                txtDienThoai.Text = selectedEmployee.HomePhone.ToString();
            }
        }

        private void btBack_Click(object sender, EventArgs e)
        {
            if (nPage - 1>0)
            {
                nPage--;
                dataGridView1.DataSource = nv.LoadRecord(nPage, nRecord); 
            }

        }

        private void btNext_Click(object sender, EventArgs e)
        {
            if (nPage - 1 < nv.DemNV()/ nRecord)
            {
                nPage++;
                dataGridView1.DataSource = nv.LoadRecord(nPage, nRecord);
            }
        }
    }
}
/*
 * Hiển thị DL ra DataGridview:
 * Đọc DL từ DataGridView lên controls:
 * Thêm button vào dataGridView
 * Phân trang DataGridView
 * Truy xuất proc bằng LinQ
 */
