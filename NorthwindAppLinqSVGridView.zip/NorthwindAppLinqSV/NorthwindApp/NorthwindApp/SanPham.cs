﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NorthwindApp
{
    class SanPham
    {
        ConnectionClass connClass;
        public SanPham()
        {
            connClass = new ConnectionClass();
        }
        //public DataTable LayDSSanPham()
        //{
        //    //str
        //}
    }
}
