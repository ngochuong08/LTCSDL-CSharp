﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLThuvien
{
    class NhanVien
    {
        ConnectionClass connClass;

        public NhanVien()
        {
            connClass = new ConnectionClass();
        }

        public DataTable LayDSNhanVien()
        {
            string caulenh = "select * from Employees";
            DataTable dt = connClass.Execute(caulenh);
            return dt;
        }

        //Lấy tên các nhóm NV
        public DataTable LayDSNhom()
        {
            string caulenh = "select * from Groups";
            DataTable dt = connClass.Execute(caulenh);
            return dt;
        }

        public void Xoanhanvien(string index_NV)
        {
            string str = "Delete from Employees where EmployeeID = " + index_NV;
            connClass.ExecutiNonQuery(str);
        }

        public void ThemNV(string ln, string fn, string bd, string add, string hp, int g)
        {
            string str = string.Format("Insert into Employees ([LastName],[FirstName],[BirthDate] ,[Address] ,[HomePhone],[GroupID] ) " +
                "values(N'{0}',N'{1}',N'{2}',N'{3}',N'{4}',{5})", ln, fn, bd, add, hp, g);
            connClass.ExecutiNonQuery(str);
        }

        public void CapNhatNV(int indexnv, string ln, string fn, string bd, string add, string hp, int g)
        {
            string caulenh = string.Format("update Employees set[LastName] = N'{0}', [FirstName] = N'{1}'," +
                "[BirthDate] = '{2}', [Address] = '{3}',[HomePhone] = '{4}', [GroupID] = '{5}' " +
                "where[EmployeeID] ={6}", ln, fn, bd, add, hp, g, indexnv);
            connClass.ExecutiNonQuery(caulenh);
        }
    }
}
