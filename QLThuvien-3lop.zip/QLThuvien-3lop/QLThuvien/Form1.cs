﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Linq.Expressions;

namespace QLThuvien
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        #region 3lop
        NhanVien nv = new NhanVien();
        void setNull()
        {
            tbLastName.Text = "";
            tbFirstName.Text = "";
            tbDienThoai.Text = "";
            tbAddress.Text = "";
            tbID.Text = "";
        }

        void HienThiNV()
        {
            DataTable dt = nv.LayDSNhanVien();
            dgvThongTin.DataSource = dt;
        }

        public void Hienthinhom()
        {
            DataTable dt = nv.LayDSNhom();
            cbTenNhom.DataSource = dt;
            cbTenNhom.DisplayMember = "GroupName";
            cbTenNhom.ValueMember = "GroupID";
        }

        private void dgvThongTin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow;
            numrow = e.RowIndex;
            tbID.Text = dgvThongTin.Rows[numrow].Cells[0].Value.ToString();
            tbLastName.Text = dgvThongTin.Rows[numrow].Cells[1].Value.ToString();
            tbFirstName.Text = dgvThongTin.Rows[numrow].Cells[2].Value.ToString();
            dtpNgaySinh.Text = dgvThongTin.Rows[numrow].Cells[5].Value.ToString();
            tbAddress.Text = dgvThongTin.Rows[numrow].Cells[7].Value.ToString();
            tbDienThoai.Text = dgvThongTin.Rows[numrow].Cells[12].Value.ToString();
        }
        private void BtThem_Click(object sender, EventArgs e)
        {
            nv.ThemNV(tbLastName.Text, tbFirstName.Text, dtpNgaySinh.Value.ToShortDateString(), tbAddress.Text , tbDienThoai.Text, cbTenNhom.SelectedIndex);
            HienThiNV();
        }
        private void btxoa_Click(object sender, EventArgs e)
        {
            int numrow;
            if (dgvThongTin.SelectedCells.Count > 0)
            {
                DialogResult dr = MessageBox.Show("Bạn có chắc xóa  không?", "Xóa bằng cấp", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    nv.Xoanhanvien(tbID.Text);
                    HienThiNV();
                    setNull();
                }
            }
            else
                MessageBox.Show("Bạn phải chọn mẩu tin cần xóa");
        }

        private void btluu_Click(object sender, EventArgs e)
        {
            if (dgvThongTin.SelectedCells.Count > 0)
            {
                try
                {
                    nv.CapNhatNV(Int16.Parse(tbID.Text), tbLastName.Text, tbFirstName.Text, dtpNgaySinh.Value.ToShortDateString(), tbAddress.Text, tbDienThoai.Text, cbTenNhom.SelectedIndex);
                    //dgvThongTin.SelectedCells.Clear();
                    HienThiNV();
                    btluu.Enabled = false;
                    bthuy.Enabled = false;
                    BtThem.Enabled = true;
                    btxoa.Enabled = true;
                }
                catch (Exception)
                {
                    
                }
            }
            else
                MessageBox.Show("Cần chọn mẫu tin muốn sửa", "Sửa nhân viên");
        }

        private void btsua_Click(object sender, EventArgs e)
        {
            btluu.Enabled = true;
            bthuy.Enabled = true;
            BtThem.Enabled = false;
            btxoa.Enabled = false;
        }

        private void bthuy_Click(object sender, EventArgs e)
        {
            btluu.Enabled = false;
            bthuy.Enabled = false;
            BtThem.Enabled = true;
            btxoa.Enabled = true;
        }
        private void btthoat_Click(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection(@"Data Source=GLC-IT-MINHLE\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True");
            string sql = "SELECT COUNT(employeeID) FROM Employees";

            SqlCommand cmd = new SqlCommand(sql, cnn);
            cmd.Connection.Open();
            int count = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();
            MessageBox.Show("So luong nhan Vien la: "+ count.ToString());
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            HienThiNV();
            Hienthinhom();
        }

        #endregion

        #region 1lop
        //SqlConnection cnn = new SqlConnection(@"Data Source=GLC-IT-MINHLE\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True");
        //private void ketnoicsdl()
        //{
        //    cnn.Open();
        //    string sql = "select * from Employees";  // lay het du lieu trong bang sinh vien
        //    SqlCommand com = new SqlCommand(sql, cnn); //bat dau truy van
        //    com.CommandType = CommandType.Text;
        //    SqlDataAdapter da = new SqlDataAdapter(com); //chuyen du lieu ve
        //    DataTable dt = new DataTable(); //tạo một kho ảo để lưu trữ dữ liệu
        //    da.Fill(dt);  // đổ dữ liệu vào kho
        //    cnn.Close();  // đóng kết nối
        //    dgvThongTin.DataSource = dt; //đổ dữ liệu vào datagridview
        //}

        //private void Addemployees()
        //{

        //    //string sql = "select * from Employees";
        //    //SqlDataAdapter da = new SqlDataAdapter(sql, cnn);
        //    try
        //    {
        //        if (tbFirstName.Text == "" || tbLastName.Text == "")
        //        {
        //            MessageBox.Show("DATA Is Not Null");
        //        }
        //        else
        //        {
        //            SqlCommand cmdstring = new SqlCommand("INSERT INTO Employees (LastName, FirstName, BirthDate, Address, HomePhone, Notes) values " +
        //                "('" + tbLastName.Text + "','" + tbFirstName.Text + "','" + dtpNgaySinh.Value.Date + "','" + tbAddress.Text + "','" + tbDienThoai.Text + "')", cnn);
        //            cnn.Open();
        //            cmdstring.CommandType = CommandType.Text;
        //            cmdstring.ExecuteNonQuery();
        //            MessageBox.Show("Data Inserted");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //    //finally
        //    //{
        //    //    if (cnn.State == ConnectionState.Open)
        //    //}
        //    //string SQLInsert = "INSERT INTO Employees (Lastname,Birthdate,Address,Homephone,Notes) values " +
        //    //    "('"+ tbHoten.Text + "','" + dtpNgaySinh.Value.Date + "','" + tbDiaChi.Text + "','" + tbDienThoai + "','" + CBBangCap.SelectedItem + "')";
        //    //SqlCommand cmd = new SqlCommand(SQLInsert, cnn);
        //    //cmd.CommandType = CommandType.Text;
        //    //cmd.ExecuteNonQuery();
        //    //DataSet ds = new DataSet();
        //    //da.Fill(ds);
        //    //SqlCommandBuilder cb = new SqlCommandBuilder(da);
        //    cnn.Close();

        //}

        //private void EditEmployees()
        //{
        //    try
        //    {
        //        if (tbFirstName.Text == "" || tbLastName.Text == "")
        //        {
        //            MessageBox.Show("Please Input Data Update");
        //        }
        //        else
        //        {
        //            string SQLEdit = "Update Employees SET LastName = '" + tbLastName.Text + "',FirstName = '" + tbFirstName.Text + "',BirthDate = '" 
        //                + dtpNgaySinh.Value.Date + "',Address = '" + tbAddress.Text + "',HomePhone = '" + tbDienThoai.Text + "'  Where EmployeeID = '" + tbID.Text + "'";
        //            cnn.Open();
        //            SqlCommand cmd = new SqlCommand(SQLEdit, cnn);
        //            cmd.CommandType = CommandType.Text;
        //            cmd.ExecuteNonQuery();
        //            MessageBox.Show("Data Updated");
        //            cnn.Close();
        //        }
        //    }catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }


        //    //SqlCommand cmdstring = new SqlCommand(("Update Employees SET LastName = '" + tbLastName.Text + "',FirstName = '" + tbFirstName.Text + "',BirthDate = '" + dtpNgaySinh.Value.Date + "',Address = '" + tbAddress.Text + "',HomePhone = '" + tbDienThoai.Text + "',Notes = '" + tbNotes.Text + "'"), cnn);
        //    //cnn.Open();
        //    //cmdstring.CommandType = CommandType.Text;
        //    //cmdstring.ExecuteNonQuery();
        //    //MessageBox.Show("Data Updated");
        //}

        //private void DelEmployee()
        //{
        //    try
        //    {
        //        if (tbFirstName.Text == "" || tbLastName.Text == "")
        //        {
        //            MessageBox.Show("Please Choose User Want Delete");
        //        }
        //        else
        //        {
        //            string SQLEdit = "Delete Employees Where EmployeeID = '" + tbID.Text + "'";
        //            cnn.Open();
        //            SqlCommand cmd = new SqlCommand(SQLEdit, cnn);
        //            cmd.CommandType = CommandType.Text;
        //            cmd.ExecuteNonQuery();
        //            MessageBox.Show("User Delete");
        //            cnn.Close();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        //private void refeshdata()
        //{
        //    tbFirstName.Text = "";
        //    tbLastName.Text = "";
        //    tbDienThoai.Text = "";
        //    tbID.Text = "";
        //    tbAddress.Text = "";
        //    dgvThongTin.Update();
        //    dgvThongTin.Refresh();
        //}
        //private void dgvThongTin_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    int numrow;
        //    numrow = e.RowIndex;
        //    tbID.Text = dgvThongTin.Rows[numrow].Cells[0].Value.ToString();
        //    tbLastName.Text = dgvThongTin.Rows[numrow].Cells[1].Value.ToString();
        //    tbFirstName.Text = dgvThongTin.Rows[numrow].Cells[2].Value.ToString();
        //    dtpNgaySinh.Text = dgvThongTin.Rows[numrow].Cells[5].Value.ToString();
        //    tbAddress.Text = dgvThongTin.Rows[numrow].Cells[7].Value.ToString();
        //    tbDienThoai.Text = dgvThongTin.Rows[numrow].Cells[12].Value.ToString();
        //}


        //private void btthoat_Click(object sender, EventArgs e)
        //{
        //    Application.Exit();
        //}

        //private void BtThem_Click(object sender, EventArgs e)
        //{
        //    Addemployees();
        //    ketnoicsdl();
        //}

        //private void btsua_Click(object sender, EventArgs e)
        //{
        //    btluu.Enabled = true;
        //    bthuy.Enabled = true;
        //    BtThem.Enabled = false;
        //    btxoa.Enabled = false;
        //}

        //private void btRefesh_Click(object sender, EventArgs e)
        //{
        //    refeshdata();
        //    ketnoicsdl();
        //}

        //private void btxoa_Click(object sender, EventArgs e)
        //{
        //    DelEmployee();
        //    ketnoicsdl();
        //}

        //private void btluu_Click(object sender, EventArgs e)
        //{
        //    EditEmployees();
        //    ketnoicsdl();
        //}

        //private void bthuy_Click(object sender, EventArgs e)
        //{
        //    btluu.Enabled = false;
        //    bthuy.Enabled = false;
        //    BtThem.Enabled = true;
        //    btxoa.Enabled = true;
        //}
        #endregion
    }
}
